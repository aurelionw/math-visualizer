# math-visualizer – Kurvendiskussionsrechner

Dieser Ordner enthält eine Webanwendung zur automatisierten Funktionsanalyse.

Die Anwendung basiert auf Python (Flask) und LaTeX zur Rechenwegdarstellung.  
Ziel ist es, mathematische Inhalte – insbesondere Polynomfunktionen – nachvollziehbar aufzubereiten.

Aktueller Stand: in Entwicklung, Veröffentlichung geplant bis Oktober 2025.
