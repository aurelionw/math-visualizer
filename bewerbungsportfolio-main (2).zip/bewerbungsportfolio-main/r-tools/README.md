# r-tools – Statistische Analysefunktionen in R

In diesem Ordner befinden sich R-Funktionen zur automatisierten Datenanalyse, u. a.:

- Einfache und multiple Regression
- ANOVA und Kruskal-Wallis-Test
- Anwendungsdatei mit Anwendungsbeispielen zu den hochgeladenen Codes

Alle Skripte sind modular aufgebaut, dokumentiert und für datenanalytische Bewerbungen zusammengestellt.
